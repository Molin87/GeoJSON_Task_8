#import libraries
import folium
import numpy

#create a map variable
map = folium.Map (location=[-26.20227,28.04363], zoom_start=7)

#create a variable to hold our image
# and also setting the width and height
logoIcon=folium.features.CustomIcon('Logo.png', icon_size=(55,55))

#create markers
folium.Marker([-26.175165966, 28.023666572],
              popup='<stromg>Parktown</strong>').add_to(map),

folium.Marker([-26.563404, 27.844164],
              popup='<stromg>Sebokeng</strong>').add_to(map),

folium.Marker([-25.731340, 28.218370],
              popup='<stromg>Pretoria</strong>').add_to(map),

#creating marker with different color
folium.Marker([-25.654448, 27.255854],
              popup='<strong>Rustenburg</strong>',
              icon=folium.Icon(color='green')).add_to(map),

folium.Marker([-27.75796, 29.9318],
              popup='<strong>Newcastle</strong>',
              icon=folium.Icon(color='pink')).add_to(map),

folium.Marker([-28.741943, 24.771944],
              popup='<strong>Kimberly</strong>',
              icon=folium.Icon(color='black')).add_to(map),

folium.Marker([-23.83333, 30.166666],
              popup='<strong>Tzaneen</strong>',
              icon=folium.Icon(color='orange')).add_to(map),

#creating marker with image
folium.Marker([-26.29999,25.923291],
              popup='<strong>Travel Agency</strong>',
              icon=logoIcon).add_to(map),


#creating circular marker
folium.CircleMarker(location=[-29.087217, 26.154898],
                    popup='<strong>Sebokeng</strong>',
                    radius=20,
                    color='#003366',
                    fill=True,
                    fill_color='#4dff4d').add_to(map)

folium.CircleMarker(location=[-25.47448, 30.97033],
                    popup='<strong>Mbombela</strong>',
                    radius=20,
                    color='#003366',
                    fill=True,
                    fill_color='#99994d').add_to(map)

folium.CircleMarker(location=[-26.9033, 27.45727],
                    popup='<strong>Parys</strong>',
                    radius=20,
                    color='#003366',
                    fill=True,
                    fill_color='#8c1aff').add_to(map)
    
#saving the file as a .html fole
map.save('map1.html')
