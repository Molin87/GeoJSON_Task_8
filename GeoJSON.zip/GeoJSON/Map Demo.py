#import libraries
import folium
import numpy
import os

#create a map variable
map = folium.Map (location=[-26.20227,28.04363], zoom_start=7)

#create a variable to hold our image
# and also setting the width and height
logoIcon=folium.features.CustomIcon('Logo.png', icon_size=(55,55))

#geojson data
overlay= os.path.join('data','overlay.json')


#create markers
folium.Marker([-25.20227,29.36340],
              popup='<stromg>Location One</strong>').add_to(map),

#creating marker with different color
folium.Marker([-26.29999,26.9999],
              popup='<strong>Location Two</strong>',
              icon=folium.Icon(color='purple')).add_to(map),

#creating marker with image
folium.Marker([-26.29999,25.923291],
              popup='<strong>Location Three</strong>',
              icon=logoIcon).add_to(map),

#creating circular marker
folium.CircleMarker(location=[-25.20227,29.94363],
                    radius=20,
                    color='#fcba03',
                    fill=True,
                    fill_color='#fcf803').add_to(map)

#Geojson overlay
folium.GeoJson(overlay, name='area').add_to(map)

    
#saving the file as a .html fole
map.save('map.html')
